
#ifndef __COMMON_ALGO_HEADER__
#define __COMMON_ALGO_HEADER__

#ifdef __cplusplus
extern "C" {
#endif

typedef void* Instance;

typedef struct Algo
{
	Instance ins;
}Algo;

typedef struct Result
{
	const char* data;
	int size;
}Result;

int InitEnv(Algo* ins, const char* deviceID, const char* modelPath);

Result* Process(Algo* ins, const char* imagePath);

int Close(Algo* ins);

#ifdef __cplusplus
}
#endif

#endif
	